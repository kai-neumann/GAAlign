#ifndef GAME_GAME_ROBOT_KINEMATICS_H_
#define GAME_GAME_ROBOT_KINEMATICS_H_

#include "game/types.h"

//class ForwardKinematics






#endif  // GAME_GAME_ROBOT_KINEMATICS_H_
