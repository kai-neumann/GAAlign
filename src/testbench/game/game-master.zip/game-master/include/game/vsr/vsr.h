#ifndef GAME_VSR_VSR_H_
#define GAME_VSR_VSR_H_

#include "game/vsr/generic_op.h"
#include "game/vsr/cga_types.h"

#endif //GAME_VSR_VSR_H_
