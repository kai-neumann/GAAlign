#ifndef GAME_GAME_VERSORS_H_
#define GAME_GAME_VERSORS_H_

#include "game/types.h"

namespace game
{
namespace cga
{



}
}



#endif // GAME_GAME_VERSORS_H_
