#ifndef GAME_GAME_FUNCTIONS_H_
#define GAME_GAME_FUNCTIONS_H_

template <int N>
auto Factorial() {

}

#endif // GAME_GAME_FUNCTIONS_H_
